<div class="container footer">
	<div class="row">
		<div class="col-md-3">
			<h3 class="footer-title">Liên kết</h3>
				<ul class="list-group list-unstyled bullet">
					<li><a href="{{route('client.product_all')}}">Tất cả sản phẩm</a></li>
				</ul>
			</h3>
		</div>
		<div class="col-md-3">
			<h3 class="footer-title">Hỗ trợ</h3>
				<ul class="list-group list-unstyled bullet">
					<li><a href="{{route('client.home')}}">Trang chủ</a></li>
					<li><a href="{{route('client.product_all')}}">Sản Phẩm</a></li>
					<li><a href="{{route('client.introduce')}}">Giới thiệu</a></li>
				</ul>
			</h3>
		</div>
		<div class="col-md-3">
			<h3 class="footer-title">Kết nối với chúng tôi</h3>
				<ul class="list-group list-unstyled bullet">
					<li>
						<span>Website bán sách của StarBook</span>
						<br>
						<a href="mailto:starbook@gmail.com">starbook@gmail.com</a>
						<br>
						<span>0909933790</span>
					</li>
				</ul>
			</h3>
		</div>
		<div class="col-md-3">
			<div class="contact-footer">
				<p class="phone">0909933790</p>
				<span class="time-normal">Thứ 2 - Thứ 6: 8:00 - 17:00</span>
				<p class="marker-first">
					<i class="glyphicon glyphicon-map-marker"></i>
					TP.Hồ Chí Mính
				</p>
				<p>
					<i class="	glyphicon glyphicon-envelope"></i>
					starbook@gmail.com
				</p>
			</div>
		</div>
		
	</div>
</div>